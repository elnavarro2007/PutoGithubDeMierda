package org.example.ie.bloque3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bloque3Application {

	public static void main(String[] args) {
		SpringApplication.run(Bloque3Application.class, args);
	}

}
